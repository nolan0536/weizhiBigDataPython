import csv
import json
import codecs
import os
# class GuosaiJSON(object):
#     def __init__(self):
#         self.store_file = open('sale_fact.json','w',encoding='utf-8')
#
#
#     def process_item(self, item, spider):
#         line_no=json.dumps(dict(item)['result'],ensure_ascii=False)+",\n"
#         self.store_file.write(line_no)
#         return item
class GuosaiCSV(object):
    def __init__(self):
        self.gscsv=open('guosaai.csv','w',encoding='utf-8')
        self.writer = csv.writer(self.gscsv)


    def process_item(self, item, spider):

        # for value in item['result']['detail'].values():
        #     print(value)
        #     # self.writer.writerow(dict(value))

        jedge=1
        print(2222222)
        id_name_key = [k for k, v in item['result']['detail'].items()]
        print("遍历字典把所有的key取出来:", id_name_key)
        if jedge<2:
            print(jedge)
            self.writer.writerow(dict(id_name_key))
            jedge=jedge+1


        id_name_values = [v for k, v in item['result']['detail'].items()]
        self.writer.writerow(dict(id_name_values))
        print("遍历字典把所有的values取出来:", id_name_values)

        return item

    def close_spider(self,spider):
        self.gscsv.close()

